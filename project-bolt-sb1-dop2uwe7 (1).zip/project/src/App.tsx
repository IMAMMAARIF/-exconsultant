import React, { useState } from 'react';
import { Scale, BookOpen, Users, Phone, Mail, MapPin, Clock, Shield, User, LogOut, ChevronDown, Gavel, FileText, Building, Briefcase, Video, HardDrive, Upload, Trash2, Play } from 'lucide-react';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Sample data for videos and storage
  const videos = [
    {
      id: 1,
      title: "Pengantar Hukum Pidana",
      thumbnail: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80",
      duration: "15:30"
    },
    {
      id: 2,
      title: "Aspek Hukum Perdata",
      thumbnail: "https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?auto=format&fit=crop&q=80",
      duration: "12:45"
    },
    {
      id: 3,
      title: "Tips Konsultasi Hukum",
      thumbnail: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80",
      duration: "08:20"
    }
  ];

  const storageInfo = {
    used: 2.5,
    total: 10,
    files: [
      { name: "Dokumen Kasus.pdf", size: "1.2 MB", type: "pdf" },
      { name: "Bukti Foto.jpg", size: "800 KB", type: "image" },
      { name: "Rekaman Meeting.mp4", size: "500 MB", type: "video" }
    ]
  };

  const services = [
    {
      icon: <Gavel className="w-8 h-8" />,
      title: "Hukum Pidana",
      description: "Penanganan kasus pidana dengan pendekatan yang profesional dan strategis."
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Hukum Perdata",
      description: "Penyelesaian sengketa perdata, kontrak, dan perjanjian antar pihak."
    },
    {
      icon: <Building className="w-8 h-8" />,
      title: "Hukum Bisnis",
      description: "Konsultasi dan pendampingan hukum untuk berbagai aspek bisnis dan korporasi."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Hukum Keluarga",
      description: "Penanganan kasus perceraian, warisan, dan permasalahan keluarga lainnya."
    },
    {
      icon: <Scale className="w-8 h-8" />,
      title: "Hukum Administrasi",
      description: "Bantuan dalam urusan administrasi negara dan perizinan."
    },
    {
      icon: <Briefcase className="w-8 h-8" />,
      title: "Hukum Ketenagakerjaan",
      description: "Penanganan masalah hubungan industrial dan hak-hak pekerja."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative h-[600px]">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80"
            alt="Law Office"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gray-900/70"></div>
        </div>
        
        <nav className="relative z-10 container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Scale className="w-8 h-8 text-white" />
              <span className="text-white text-xl font-semibold">LexConsult</span>
            </div>
            <div className="hidden md:flex items-center space-x-8 text-white">
              <a href="#services" className="hover:text-yellow-400">Layanan</a>
              <a href="#videos" className="hover:text-yellow-400">Video</a>
              <a href="#about" className="hover:text-yellow-400">Tentang Kami</a>
              <a href="#team" className="hover:text-yellow-400">Tim</a>
              <a href="#contact" className="hover:text-yellow-400">Kontak</a>
              
              {/* Member Account Menu */}
              {isLoggedIn ? (
                <div className="relative">
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="flex items-center space-x-2 hover:text-yellow-400 focus:outline-none"
                  >
                    <User className="w-5 h-5" />
                    <span>John Doe</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>
                  
                  {isDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 text-gray-800">
                      <a href="/profile" className="block px-4 py-2 hover:bg-gray-100">
                        <div className="flex items-center space-x-2">
                          <User className="w-4 h-4" />
                          <span>Profil Saya</span>
                        </div>
                      </a>
                      <a href="/storage" className="block px-4 py-2 hover:bg-gray-100">
                        <div className="flex items-center space-x-2">
                          <HardDrive className="w-4 h-4" />
                          <span>Storage Saya</span>
                        </div>
                      </a>
                      <a href="/cases" className="block px-4 py-2 hover:bg-gray-100">
                        <div className="flex items-center space-x-2">
                          <Scale className="w-4 h-4" />
                          <span>Kasus Saya</span>
                        </div>
                      </a>
                      <button
                        onClick={() => setIsLoggedIn(false)}
                        className="w-full text-left px-4 py-2 hover:bg-gray-100 text-red-600"
                      >
                        <div className="flex items-center space-x-2">
                          <LogOut className="w-4 h-4" />
                          <span>Keluar</span>
                        </div>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => setIsLoggedIn(true)}
                    className="px-4 py-2 rounded-md bg-yellow-500 text-gray-900 font-semibold hover:bg-yellow-400 transition-colors"
                  >
                    Masuk
                  </button>
                  <button className="px-4 py-2 rounded-md border border-white text-white hover:bg-white hover:text-gray-900 transition-colors">
                    Daftar
                  </button>
                </div>
              )}
            </div>
          </div>
        </nav>

        <div className="relative z-10 container mx-auto px-6 pt-32">
          <h1 className="text-white text-4xl md:text-6xl font-bold max-w-3xl">
            Solusi Hukum Profesional untuk Kebutuhan Anda
          </h1>
          <p className="text-gray-200 mt-6 max-w-2xl text-lg">
            Tim ahli hukum kami siap membantu Anda menyelesaikan berbagai permasalahan hukum dengan pendekatan yang profesional dan efektif.
          </p>
          <button className="mt-8 bg-yellow-500 text-gray-900 px-8 py-3 rounded-md font-semibold hover:bg-yellow-400 transition-colors">
            Konsultasi Gratis
          </button>
        </div>
      </header>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Layanan Kami</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
                <div className="text-yellow-500 mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Video Gallery Section */}
      <section id="videos" className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Video Edukasi Hukum</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {videos.map((video) => (
              <div key={video.id} className="bg-white rounded-lg shadow-lg overflow-hidden group">
                <div className="relative">
                  <img 
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-12 h-12 text-white" />
                  </div>
                  <span className="absolute bottom-2 right-2 bg-black text-white px-2 py-1 text-sm rounded">
                    {video.duration}
                  </span>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-lg mb-2">{video.title}</h3>
                  <button className="text-yellow-500 hover:text-yellow-600">
                    Tonton Video
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Storage Management Section (Only visible when logged in) */}
      {isLoggedIn && (
        <section id="storage" className="py-20 bg-gray-50">
          <div className="container mx-auto px-6">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Storage Management</h2>
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="mb-8">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Storage Used: {storageInfo.used}GB / {storageInfo.total}GB</span>
                  <button className="flex items-center space-x-2 bg-yellow-500 text-gray-900 px-4 py-2 rounded hover:bg-yellow-400">
                    <Upload className="w-4 h-4" />
                    <span>Upload File</span>
                  </button>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-yellow-500 h-2.5 rounded-full"
                    style={{ width: `${(storageInfo.used / storageInfo.total) * 100}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama File</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ukuran</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tipe</th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {storageInfo.files.map((file, index) => (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap">{file.name}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{file.size}</td>
                        <td className="px-6 py-4 whitespace-nowrap uppercase">{file.type}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-right">
                          <button className="text-red-500 hover:text-red-700">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* About Section */}
      <section id="about" className="py-20">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1453728013993-6d66e9c9123a?auto=format&fit=crop&q=80"
                alt="Law Office Interior"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6">Tentang LexConsult</h2>
              <p className="text-gray-600 mb-6">
                Dengan pengalaman lebih dari 15 tahun dalam bidang hukum, kami telah membantu ribuan klien menyelesaikan berbagai permasalahan hukum mereka. Tim kami terdiri dari para ahli hukum berpengalaman yang berkomitmen untuk memberikan pelayanan terbaik.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <p className="text-3xl font-bold text-yellow-500">500+</p>
                  <p className="text-gray-600">Klien Puas</p>
                </div>
                <div>
                  <p className="text-3xl font-bold text-yellow-500">15+</p>
                  <p className="text-gray-600">Tahun Pengalaman</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-900 text-white">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold text-center mb-12">Hubungi Kami</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex items-center space-x-4">
              <Phone className="w-6 h-6 text-yellow-500" />
              <div>
                <p className="font-semibold">Telepon</p>
                <p>(0812-7262-1762)</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Mail className="w-6 h-6 text-yellow-500" />
              <div>
                <p className="font-semibold">Email</p>
                <p>info@lexconsult.com</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <MapPin className="w-6 h-6 text-yellow-500" />
              <div>
                <p className="font-semibold">Alamat</p>
                <p>Jl. dr. haru II, no. 91, tanjung karang timur, Bandar Lampung</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-8">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Scale className="w-6 h-6" />
              <span className="text-white font-semibold">LexConsult</span>
            </div>
            <div className="text-sm">
              © 2024 LexConsult. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;